// 초록 좀비 손전등 (Chorok Zombie 모드가 추가). 원본 Cursed Fog 에는 없는 기능.
//
// 모드가 매 프레임 czFlashlights 텍스처(32x1 RGBA8, Iris customTexture)에 켜진 손전등을 적어 넣는다.
//   px0  R=다른 사람 손전등 수, G=내 손전등(카메라)이 켜졌으면 255
//   px1~3  기준점 x/y/z (정수 블록, 24비트 + 2^23 오프셋, RGB)
//   손전등 i (px 4+3i .. 6+3i): 기준점에 대한 위치 x,y,z 와 방향 x,y,z, 각 16비트(앞 바이트가 상위)
//     위치는 [-128, 128) 블록, 방향은 [-1, 1]
//   px31 R=어둠(0 = 평소, 255 = 완전히 깜깜). 정전된 실내·형광등 깜빡임 연출. 손전등 빛은 어둡게 하지 않는다.
// 위치를 카메라가 아닌 정수 기준점에 대해 적어서, 셰이더가 정확한 cameraPosition 으로 다시 빼면
// 모드가 값을 적은 시점이 한 프레임 어긋나도 빛이 흔들리지 않는다.

uniform sampler2D czFlashlights;
uniform vec3 cameraPosition;

#define CZ_MAX_LIGHTS 8
#define CZ_RANGE 28.0
#define CZ_STRENGTH 2.4
#define CZ_COS_INNER 0.975   // 약 13도 — 가운데 밝은 원
#define CZ_COS_OUTER 0.88    // 약 28도 — 가장자리
const vec3 CZ_COLOR = vec3(1.0, 0.93, 0.80);

float czByte(vec4 px, int i) { return floor(px[i] * 255.0 + 0.5); }

// 장면 밝기 배율(1 = 평소). 모드가 없거나 아직 안 적었으면 0 이 읽혀 1.0.
float czDim() { return 1.0 - texelFetch(czFlashlights, ivec2(31, 0), 0).r; }

float czU16(vec4 px, int hi) { return czByte(px, hi) * 256.0 + czByte(px, hi + 1); }

float czI24(vec4 px) { return czByte(px, 0) * 65536.0 + czByte(px, 1) * 256.0 + czByte(px, 2) - 8388608.0; }

// 한 손전등이 그 점에 주는 빛. playerPos·origin 은 카메라 기준(월드 축).
float czCone(vec3 playerPos, vec3 normal, vec3 origin, vec3 dir) {
    vec3 d = playerPos - origin;
    float dist = length(d);
    if (dist > CZ_RANGE || dist < 1e-3) return 0.0;
    vec3 ld = d / dist;
    float cone = smoothstep(CZ_COS_OUTER, CZ_COS_INNER, dot(ld, dir));
    if (cone <= 0.0) return 0.0;
    // 빛을 등진 면(벽 너머)은 밝히지 않는다 — 다른 사람 손전등이 벽을 뚫고 새는 것을 대부분 막는다.
    float facing = clamp(dot(normal, -ld), 0.0, 1.0);
    float fade = 1.0 - dist / CZ_RANGE;
    float att = fade * fade / (1.0 + 0.012 * dist * dist);
    return cone * facing * att;
}

// 화면 한 점(깊이 depth)에 들어오는 손전등 빛의 세기(색 포함). 하늘·손은 0.
vec3 czFlashlight(vec2 uv, float depth, mat4 projInv, mat4 mvInv) {
    if (depth >= 1.0 || depth < 0.56) return vec3(0.0);
    vec4 header = texelFetch(czFlashlights, ivec2(0, 0), 0);
    int count = int(czByte(header, 0));
    bool self = czByte(header, 1) > 127.0;
    if (count == 0 && !self) return vec3(0.0);

    vec4 v = projInv * vec4(vec3(uv, depth) * 2.0 - 1.0, 1.0);
    vec3 viewPos = v.xyz / v.w;
    vec3 playerPos = (mvInv * vec4(viewPos, 1.0)).xyz;
    vec3 normal = normalize(cross(dFdx(playerPos), dFdy(playerPos)));
    if (dot(normal, playerPos) > 0.0) normal = -normal;

    float light = 0.0;
    if (self) {
        // 내 손전등: 카메라에서 바라보는 방향으로(손 위치만큼 살짝 오른쪽 아래).
        vec3 forward = normalize((mvInv * vec4(0.0, 0.0, -1.0, 0.0)).xyz);
        vec3 hand = (mvInv * vec4(0.18, -0.12, 0.0, 0.0)).xyz;
        light += czCone(playerPos, normal, hand, forward);
    }
    vec3 anchor = vec3(
        czI24(texelFetch(czFlashlights, ivec2(1, 0), 0)),
        czI24(texelFetch(czFlashlights, ivec2(2, 0), 0)),
        czI24(texelFetch(czFlashlights, ivec2(3, 0), 0))
    );
    for (int i = 0; i < CZ_MAX_LIGHTS; i++) {
        if (i >= count) break;
        vec4 a = texelFetch(czFlashlights, ivec2(4 + i * 3, 0), 0);
        vec4 b = texelFetch(czFlashlights, ivec2(5 + i * 3, 0), 0);
        vec4 c = texelFetch(czFlashlights, ivec2(6 + i * 3, 0), 0);
        vec3 rel = vec3(czU16(a, 0), czU16(a, 2), czU16(b, 0)) / 65535.0 * 256.0 - 128.0;
        vec3 dir = normalize(vec3(czU16(b, 2), czU16(c, 0), czU16(c, 2)) / 65535.0 * 2.0 - 1.0);
        light += czCone(playerPos, normal, anchor + rel - cameraPosition, dir);
    }
    return CZ_COLOR * CZ_STRENGTH * light;
}
